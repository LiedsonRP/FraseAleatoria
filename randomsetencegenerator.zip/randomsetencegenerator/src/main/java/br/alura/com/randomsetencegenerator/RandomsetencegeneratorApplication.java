package br.alura.com.randomsetencegenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RandomsetencegeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(RandomsetencegeneratorApplication.class, args);
	}

}
